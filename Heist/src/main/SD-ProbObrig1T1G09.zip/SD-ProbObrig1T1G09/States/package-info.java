/**
 * States package, it contains all the States of the different entities
 * as well as the states of the Assault Parties and the Rooms.
 */
package States;