/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package States;

/**
 *
 * @author Ricardo Filipe
 * @author Marc Wagner
 */
public class RoomStates {
    public final static int ROOM_EMPTY = 0,
    BEING_STOLEN = 1,
    ROB_AGAIN = 3,
    NOT_VISITED = 2;
}
