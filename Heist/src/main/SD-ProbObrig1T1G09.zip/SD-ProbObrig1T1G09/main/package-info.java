/**
 * Main package, it contains the constants file, the simulation code and the definition of
 * the entities: MasterThief and OrdinaryThief.
 */
package main;