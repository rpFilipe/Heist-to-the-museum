/**
 * This package contains the GeneralRepository Monitor and all other interfaces to the entities 
 * to access to the methods as well as the other monitors.
 */
package monitors.GeneralRepository;