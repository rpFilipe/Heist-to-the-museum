/**
 * This package contains the AssaultParty Monitor and all other interfaces to the entities 
 * to access to the methods.
 */
package monitors.AssaultParty;